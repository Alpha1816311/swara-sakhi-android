package org.swarasakhi.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val LavenderPrimary = Color(0xFF7E57C2)
val LavenderContainer = Color(0xFFEDE7F6)
val SoftPink = Color(0xFFEC407A)
val SoftPinkContainer = Color(0xFFFCE4EC)
val BackgroundLight = Color(0xFFF8F5FA)
val SurfaceLight = Color(0xFFFFFFFF)
val NavyText = Color(0xFF1E1926)

private val LightColorScheme = lightColorScheme(
    primary = LavenderPrimary,
    onPrimary = Color.White,
    primaryContainer = LavenderContainer,
    onPrimaryContainer = NavyText,
    secondary = SoftPink,
    onSecondary = Color.White,
    secondaryContainer = SoftPinkContainer,
    onSecondaryContainer = NavyText,
    background = BackgroundLight,
    onBackground = NavyText,
    surface = SurfaceLight,
    onSurface = NavyText
)

@Composable
fun SwaraSakhiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
