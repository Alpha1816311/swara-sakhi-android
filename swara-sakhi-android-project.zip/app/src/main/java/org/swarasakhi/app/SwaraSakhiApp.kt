package org.swarasakhi.app

import android.app.Application
import org.swarasakhi.app.data.SwaraSakhiDatabase

class SwaraSakhiApp : Application() {
    val database: SwaraSakhiDatabase by lazy { SwaraSakhiDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
    }
}
