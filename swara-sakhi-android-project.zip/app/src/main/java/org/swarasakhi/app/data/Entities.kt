package org.swarasakhi.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "essential_boxes")
data class EssentialBoxEntity(
    @PrimaryKey val id: String,
    val name: String,
    val location: String,
    val building: String,
    val floor: String,
    val padsAvailable: Int,
    val pouchesAvailable: Int,
    val lastUpdated: Long,
    val isActive: Boolean = true,
    val qrCodeData: String
)

@Entity(tableName = "inventory_transactions")
data class InventoryTransactionEntity(
    @PrimaryKey val id: String,
    val boxId: String,
    val boxLocation: String,
    val padsCollected: Int,
    val pouchesCollected: Int,
    val timestamp: Long,
    val status: String
)

@Entity(tableName = "cycle_entries")
data class CycleEntryEntity(
    @PrimaryKey val id: String,
    val startDate: String, // YYYY-MM-DD
    val durationDays: Int,
    val cycleLengthDays: Int,
    val flowIntensity: String,
    val notes: String? = null
)

@Entity(tableName = "waste_bins")
data class WasteBinEntity(
    @PrimaryKey val id: String,
    val locationDescription: String,
    val building: String,
    val status: String,
    val lastInspectionDate: Long,
    val lastInspectionNotes: String,
    val collectionTimestamp: Long? = null,
    val authorizedRoute: String
)

@Entity(tableName = "user_reports")
data class UserReportEntity(
    @PrimaryKey val id: String,
    val category: String,
    val targetId: String?,
    val description: String,
    val submittedAt: Long
)
