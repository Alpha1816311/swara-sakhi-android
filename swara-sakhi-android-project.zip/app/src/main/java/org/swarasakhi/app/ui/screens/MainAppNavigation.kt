package org.swarasakhi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Cycle : Screen("cycle", "My Cycle", Icons.Default.Favorite)
    object Essentials : Screen("essentials", "Boxes", Icons.Default.MedicalServices)
    object Care : Screen("care", "Care", Icons.Default.MenuBook)
    object Disposal : Screen("disposal", "Disposal", Icons.Default.DeleteOutline)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppNavigation() {
    var selectedScreen by remember { mutableStateOf<Screen>(Screen.Home) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selectedScreen.title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                listOf(
                    Screen.Home,
                    Screen.Cycle,
                    Screen.Essentials,
                    Screen.Care,
                    Screen.Disposal
                ).forEach { screen ->
                    NavigationBarItem(
                        selected = selectedScreen == screen,
                        onClick = { selectedScreen = screen },
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedScreen) {
                Screen.Home -> HomeScreenCompose()
                Screen.Cycle -> CycleScreenCompose()
                Screen.Essentials -> EssentialsScreenCompose()
                Screen.Care -> CareScreenCompose()
                Screen.Disposal -> DisposalScreenCompose()
            }
        }
    }
}

@Composable
fun HomeScreenCompose() {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Swara Sakhi Dashboard - Demo Data")
    }
}

@Composable
fun CycleScreenCompose() {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Menstrual Cycle Tracker - Estimates only, not medical diagnosis")
    }
}

@Composable
fun EssentialsScreenCompose() {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Campus Essential Boxes (SWARA-001, 002, 003)")
    }
}

@Composable
fun CareScreenCompose() {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Care & Support - Hygiene & Safe Disposal")
    }
}

@Composable
fun DisposalScreenCompose() {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Sanitary Waste Management & Handover Tracking")
    }
}
