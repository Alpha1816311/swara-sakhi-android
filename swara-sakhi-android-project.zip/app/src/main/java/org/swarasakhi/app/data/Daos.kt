package org.swarasakhi.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EssentialBoxDao {
    @Query("SELECT * FROM essential_boxes WHERE isActive = 1")
    fun getAllBoxes(): Flow<List<EssentialBoxEntity>>

    @Query("SELECT * FROM essential_boxes WHERE id = :boxId")
    suspend fun getBoxById(boxId: String): EssentialBoxEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoxes(boxes: List<EssentialBoxEntity>)

    @Update
    suspend fun updateBox(box: EssentialBoxEntity)

    @Transaction
    suspend fun collectSupplies(
        boxId: String,
        pads: Int,
        pouches: Int,
        txId: String,
        timestamp: Long
    ): Boolean {
        val box = getBoxById(boxId) ?: return false
        if (pads > box.padsAvailable || pouches > box.pouchesAvailable) return false
        if (pads < 0 || pouches < 0) return false

        val updated = box.copy(
            padsAvailable = box.padsAvailable - pads,
            pouchesAvailable = box.pouchesAvailable - pouches,
            lastUpdated = timestamp
        )
        updateBox(updated)
        return true
    }
}

@Dao
interface InventoryTransactionDao {
    @Query("SELECT * FROM inventory_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<InventoryTransactionEntity>>

    @Insert
    suspend fun insertTransaction(tx: InventoryTransactionEntity)
}

@Dao
interface CycleEntryDao {
    @Query("SELECT * FROM cycle_entries ORDER BY startDate DESC")
    fun getAllEntries(): Flow<List<CycleEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertEntry(entry: CycleEntryEntity)

    @Query("DELETE FROM cycle_entries WHERE id = :id")
    suspend fun deleteEntry(id: String)

    @Query("DELETE FROM cycle_entries")
    suspend fun deleteAllHealthData()
}

@Dao
interface WasteBinDao {
    @Query("SELECT * FROM waste_bins")
    fun getAllBins(): Flow<List<WasteBinEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBins(bins: List<WasteBinEntity>)

    @Update
    suspend fun updateBin(bin: WasteBinEntity)
}

@Dao
interface UserReportDao {
    @Query("SELECT * FROM user_reports ORDER BY submittedAt DESC")
    fun getAllReports(): Flow<List<UserReportEntity>>

    @Insert
    suspend fun insertReport(report: UserReportEntity)
}
