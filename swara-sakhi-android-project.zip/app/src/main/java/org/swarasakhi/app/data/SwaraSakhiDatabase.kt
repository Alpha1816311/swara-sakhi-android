package org.swarasakhi.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        EssentialBoxEntity::class,
        InventoryTransactionEntity::class,
        CycleEntryEntity::class,
        WasteBinEntity::class,
        UserReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SwaraSakhiDatabase : RoomDatabase() {
    abstract fun boxDao(): EssentialBoxDao
    abstract fun transactionDao(): InventoryTransactionDao
    abstract fun cycleDao(): CycleEntryDao
    abstract fun wasteBinDao(): WasteBinDao
    abstract fun reportDao(): UserReportDao

    companion object {
        @Volatile
        private var INSTANCE: SwaraSakhiDatabase? = null

        fun getDatabase(context: Context): SwaraSakhiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SwaraSakhiDatabase::class.java,
                    "swara_sakhi_database"
                )
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedInitialData(database)
                    }
                }
            }
        }

        suspend fun seedInitialData(database: SwaraSakhiDatabase) {
            val now = System.currentTimeMillis()
            val initialBoxes = listOf(
                EssentialBoxEntity(
                    id = "SWARA-001",
                    name = "Block A Washroom Dispenser",
                    location = "Block A Washroom",
                    building = "Academic Block A",
                    floor = "Ground Floor",
                    padsAvailable = 12,
                    pouchesAvailable = 20,
                    lastUpdated = now,
                    isActive = true,
                    qrCodeData = "SWARA-BOX:SWARA-001:BLOCK-A-WASHROOM"
                ),
                EssentialBoxEntity(
                    id = "SWARA-002",
                    name = "Library Restroom Box",
                    location = "Library Washroom",
                    building = "Central Library",
                    floor = "1st Floor",
                    padsAvailable = 3,
                    pouchesAvailable = 8,
                    lastUpdated = now,
                    isActive = true,
                    qrCodeData = "SWARA-BOX:SWARA-002:LIBRARY-WASHROOM"
                ),
                EssentialBoxEntity(
                    id = "SWARA-003",
                    name = "Canteen Restroom Box",
                    location = "Canteen Washroom",
                    building = "Student Amenities",
                    floor = "Ground Floor",
                    padsAvailable = 0,
                    pouchesAvailable = 5,
                    lastUpdated = now,
                    isActive = true,
                    qrCodeData = "SWARA-BOX:SWARA-003:CANTEEN-WASHROOM"
                )
            )
            database.boxDao().insertBoxes(initialBoxes)

            val initialBins = listOf(
                WasteBinEntity(
                    id = "BIN-W01",
                    locationDescription = "Block A Ground Floor Sanitary Disposal Unit",
                    building = "Block A",
                    status = "Needs Collection",
                    lastInspectionDate = now - 86400000,
                    lastInspectionNotes = "Liner 80% full. Odor neutral.",
                    authorizedRoute = "Campus Bio-Solid Waste Line #1"
                ),
                WasteBinEntity(
                    id = "BIN-W02",
                    locationDescription = "Library 1st Floor Dedicated Disposal Bin",
                    building = "Library",
                    status = "Collected",
                    lastInspectionDate = now - 18000000,
                    lastInspectionNotes = "Cleaned and relined.",
                    collectionTimestamp = now - 10800000,
                    authorizedRoute = "Campus Bio-Solid Waste Line #2"
                ),
                WasteBinEntity(
                    id = "BIN-W03",
                    locationDescription = "Canteen Washroom Sanitary Bin",
                    building = "Canteen",
                    status = "Not Inspected",
                    lastInspectionDate = now - 259200000,
                    lastInspectionNotes = "Pending inspection",
                    authorizedRoute = "Campus Bio-Solid Waste Line #1"
                )
            )
            database.wasteBinDao().insertBins(initialBins)
        }
    }
}
