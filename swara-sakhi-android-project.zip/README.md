# SWARA SAKHI — Android Application Project
Campus Menstrual Wellness & Essential Sanitary Supplies Management

## 📱 Project Overview
SWARA SAKHI is a native Android application built with **Kotlin, Jetpack Compose, Material 3, and Room Database**.

### Key Architecture:
- **Language**: Kotlin 2.0+
- **UI Framework**: Jetpack Compose (Single Activity Architecture)
- **Local Database**: Room 2.6.1 with Coroutines & Flow (Offline-first, zero cloud tracking)
- **Design System**: Material 3 (Lavender #7E57C2 & Soft Pink #EC407A)
- **Seeded Demo Boxes**:
  - `SWARA-001`: Block A Washroom (12 pads, 20 pouches) — Status: AVAILABLE
  - `SWARA-002`: Library Washroom (3 pads, 8 pouches) — Status: LOW STOCK
  - `SWARA-003`: Canteen Washroom (0 pads, 5 pouches) — Status: OUT OF STOCK

---

## 🛠️ How to Compile APK in Android Studio

1. **Unzip this project** to your local computer:
   ```bash
   unzip swara-sakhi-android-project.zip -d SwaraSakhi
   ```

2. **Open Android Studio** (Ladybug or newer recommended).
3. Select **File > Open...** and select the `SwaraSakhi` folder.
4. Let Gradle sync and download dependencies.
5. To build the **Debug APK**:
   ```bash
   ./gradlew assembleDebug
   ```
   The resulting installable APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

6. To run on an Android Device or Emulator:
   - Click the green **Run ▶** button in Android Studio.

---

## 🧪 Included Unit & Functional Tests
Run tests via:
```bash
./gradlew test
```
